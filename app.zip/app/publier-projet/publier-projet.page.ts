import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publier-projet',
  templateUrl: './publier-projet.page.html',
  styleUrls: ['./publier-projet.page.scss'],
})
export class PublierProjetPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
