import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postulation',
  templateUrl: './postulation.page.html',
  styleUrls: ['./postulation.page.scss'],
})
export class PostulationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
