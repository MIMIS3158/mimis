import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-dev',
  templateUrl: './profile-dev.page.html',
  styleUrls: ['./profile-dev.page.scss'],
})
export class ProfileDevPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
