import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-entrepreneur',
  templateUrl: './profile-entrepreneur.page.html',
  styleUrls: ['./profile-entrepreneur.page.scss'],
})
export class ProfileEntrepreneurPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
